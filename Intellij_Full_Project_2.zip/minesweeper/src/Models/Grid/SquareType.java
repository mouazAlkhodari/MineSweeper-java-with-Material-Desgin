package Models.Grid;

public enum SquareType {
    Empty,Mine,Shield,HeroShield;
}
