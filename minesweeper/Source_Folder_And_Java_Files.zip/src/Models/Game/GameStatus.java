package Models.Game;

/**
 *
 * @author Omar
 */
public enum GameStatus{
    FirstMove,Running,Finish
}
