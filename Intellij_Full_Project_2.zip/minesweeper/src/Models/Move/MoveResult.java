package Models.Move;

import Models.Grid.SquareStatus;

public class MoveResult {
    private int ScoreChange;
    private SquareStatus newStatus;
}
