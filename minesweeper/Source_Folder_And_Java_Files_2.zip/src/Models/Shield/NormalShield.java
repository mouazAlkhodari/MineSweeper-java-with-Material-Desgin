package Models.Shield;

public class NormalShield extends Shield {
}
