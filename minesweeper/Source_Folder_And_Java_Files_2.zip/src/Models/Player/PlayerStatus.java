package Models.Player;

public enum PlayerStatus{
    Playing,waiting,Lose,win
}
