package Models.Game;

public enum WhenHitMine {
    Lose,Continue
}
