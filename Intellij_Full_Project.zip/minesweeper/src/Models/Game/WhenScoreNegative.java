package Models.Game;

public enum WhenScoreNegative {
    End,Continue
}
