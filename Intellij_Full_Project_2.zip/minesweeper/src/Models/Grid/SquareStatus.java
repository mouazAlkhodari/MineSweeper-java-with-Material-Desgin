package Models.Grid;

public enum SquareStatus {
    Closed,OpenedEmpty,OpenedNumber,OpenedMine,Marked;
}

