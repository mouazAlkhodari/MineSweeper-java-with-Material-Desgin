package MineSweeperGameDefineException;

public class TimeOutException extends Exception {

}
