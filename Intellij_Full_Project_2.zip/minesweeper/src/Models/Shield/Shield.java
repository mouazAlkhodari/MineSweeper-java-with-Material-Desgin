package Models.Shield;

public abstract class Shield {
}
