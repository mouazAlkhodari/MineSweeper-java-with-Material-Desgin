package Models.Shield;

public class HeroShield extends Shield{

}
