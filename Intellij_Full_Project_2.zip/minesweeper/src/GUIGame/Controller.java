package GUIGame;


import java.awt.*;

public class Controller {
}
