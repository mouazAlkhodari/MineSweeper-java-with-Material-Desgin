package Models.Move;

public enum MoveType{Reveal,Mark}
